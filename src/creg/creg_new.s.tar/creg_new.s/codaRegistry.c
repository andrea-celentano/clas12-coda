
/* codaRegistry.c */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <pthread.h>

#include <X11/Intrinsic.h>
#include <X11/Xatom.h>
#include <X11/StringDefs.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>


#define DEBUG


#include "codaRegistry.h"


static pthread_mutex_t handler_lock = PTHREAD_MUTEX_INITIALIZER;


#define HANDLER_LOCK    {pthread_mutex_lock(&handler_lock);/*printf("HANDLER_LOCK\n");*/}
#define HANDLER_UNLOCK  {pthread_mutex_unlock(&handler_lock);/*printf("HANDLER_UNLOCK\n");*/}


/* Maximum size property that can be read at one time by this module */
#define MAX_PROP_WORDS 100000





/* The default X error handler gets saved here, so that it can be invoked if an error occurs that we can't handle */
static int	(*defaultHandler) (Display *display, XErrorEvent *eventPtr) = NULL;

static int	  ErrorProc (Display *display, XErrorEvent *errEventPtr);
static void	  AppendPropCarefully (Display *display, Window window, Atom property,
                                   char *value, int length, PendingCommand *pendingPtr);
static void	  RegAddName (NameRegistry *regPtr, char *name, Window commWindow);
static NameRegistry *codaRegOpen (Display *display, int lock);
static void	  codaRegClose (NameRegistry *regPtr);
static void	  RegDeleteName (NameRegistry *regPtr, char *name);
static Window RegFindName (NameRegistry *regPtr, char *name);
static Bool	  SendRestrictProc (Display *display, XEvent *eventPtr, char *arg);
static void	  UpdateCommWindow (Display *display,Window window,char *name);
static int	  ValidateWindowName (Display *dispPtr, char *name, Window commWindow, int oldOK);

static int	  ServerSecure_hide (Display *dispPtr);

/*
 *----------------------------------------------------------------------
 *
 * RegOpen --
 *
 *	This procedure loads the name registry for a display into
 *	memory so that it can be manipulated.
 *
 * Results:
 *	The return value is a pointer to the loaded registry.
 *
 * Side effects:
 *	If "lock" is set then the server will be locked.  It is the
 *	caller's responsibility to call RegClose when finished with
 *	the registry, so that we can write back the registry if
 *	neeeded, unlock the server if needed, and free memory.
 *
 *----------------------------------------------------------------------
 */

/*
int XGetWindowProperty(display, w, property, long_offset, long_length, delete, req_type, 
                        actual_type_return, actual_format_return, nitems_return, bytes_after_return, 
                        prop_return)
      Display *display;
      Window w;
      Atom property;
      long long_offset, long_length;
      Bool delete;
      Atom req_type; 
      Atom *actual_type_return;
      int *actual_format_return;
      unsigned long *nitems_return;
      unsigned long *bytes_after_return;
      unsigned char **prop_return;
*/


/*
   display: Display whose name registry is to be opened
   lock: Non-zero means lock the window server when opening the registry, so no-one
		 else can use the registry until we close it
*/
static NameRegistry *
codaRegOpen(Display *display, int lock)
{
  NameRegistry *regPtr;
  int result, actualFormat;
  unsigned long bytesAfter;
  Atom registryProperty, actualType;
  long long_offset, long_length;

#ifdef DEBUG
  printf("codaRegistry::codaRegOpen reached\n");fflush(stdout);
#endif
  /*
  Display *disp = XOpenDisplay(NULL);
  printf("display=0x%08x, disp=0x%08x\n",display,disp);
  display = disp;
  */

  regPtr = (NameRegistry *) malloc(sizeof(NameRegistry));
  regPtr->dispPtr = display;
  regPtr->locked = 0;
  regPtr->modified = 0;
  regPtr->allocedByX = 1;

  if (lock)
  {
#ifdef DEBUG
    printf(">>> codaRegistry::codaRegOpen: lock !!!!!!!!!!!!!\n");fflush(stdout);
#endif
    XGrabServer(display);
#ifdef DEBUG
    printf(">>> codaRegistry::codaRegOpen 1\n");fflush(stdout);
#endif
    regPtr->locked = 1;
  }

  /* Read the registry property */
#ifdef DEBUG
  printf(">>> codaRegistry::codaRegOpen 2\n");fflush(stdout);
#endif
  registryProperty = XInternAtom(display,"CODARegistry",False);
#ifdef DEBUG
  printf(">>> codaRegistry::codaRegOpen 3\n");fflush(stdout);
#endif

regPtr->propLength = 0; /* sergey : ??? */
long_offset = 0;
long_length = 10000;

#ifdef DEBUG
  printf(">>> codaRegistry::codaRegOpen 4\n");fflush(stdout);
#endif
  defaultHandler = XSetErrorHandler(ErrorProc);
#ifdef DEBUG
  printf(">>> codaRegistry::codaRegOpen 5\n");fflush(stdout);
#endif
  result = XGetWindowProperty(display,
				              (Window)RootWindow(display, 0),
				              (Atom)registryProperty,
				              long_offset, long_length,
				              (Bool)False,
                              (Atom)XA_STRING,
                              (Atom *)&actualType,
                              (int *)&actualFormat,
				              (unsigned long *)&regPtr->propLength,
                              (unsigned long *)&bytesAfter,
				              (unsigned char **)&regPtr->property);

#ifdef DEBUG
  printf("\n>>> codaRegistry::codaRegOpen: result=%d\n",result);fflush(stdout);
  printf(">>>    actualType=%d\n",actualType);fflush(stdout);
  printf(">>>    actualFormat=%d\n",actualFormat);fflush(stdout);
  printf(">>>    regPtr->propLength=%d\n",regPtr->propLength);fflush(stdout);
  printf(">>>    bytesAfter=%d\n",bytesAfter);fflush(stdout);
  printf(">>>    regPtr->property=>%s<\n\n",regPtr->property);fflush(stdout);
#endif

  XSetErrorHandler(defaultHandler);
  if (actualType == None)
  {
#ifdef DEBUG
    printf("\ncodaRegistry::The property actualType = None\n\n");fflush(stdout);
#endif
    regPtr->propLength = 0;
    regPtr->property = NULL;
  }
  else if ((result != Success) || (actualFormat != 8) || (actualType != XA_STRING))
  {
#ifdef DEBUG
    printf("\ncodaRegistry::The property is improperly formed, delete it !!!\n\n");fflush(stdout);
#endif      
    if (regPtr->property != NULL)
    {
	  XFree(regPtr->property);
	  regPtr->propLength = 0;
	  regPtr->property = NULL;
    }
    XDeleteProperty(display, RootWindow(display, 0), registryProperty);
  }
    
  /*
   * Xlib placed an extra null byte after the end of the property, just
   * to make sure that it is always NULL-terminated.  Be sure to include
   * this byte in our count if it's needed to ensure null termination
   * (note: as of 8/95 I'm no longer sure why this code is needed;  seems
   * like it shouldn't be).
   */
    
  if ((regPtr->propLength > 0) && (regPtr->property[regPtr->propLength-1] != 0))
  {
    regPtr->propLength++;
  }

#ifdef DEBUG
  printf("\n>>> codaRegistry::codaRegOpen: returns=0x%08x\n\n",regPtr);fflush(stdout);
#endif
  return(regPtr);
}

/*
 *----------------------------------------------------------------------
 *
 * RegFindName --
 *
 *	Given an open name registry, this procedure finds an entry
 *	with a given name, if there is one, and returns information
 *	about that entry.
 *
 * Results:
 *	The return value is the X identifier for the comm window for
 *	the application named "name", or None if there is no such
 *	entry in the registry.
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

/*
  regPtr - Pointer to a registry opened with a previous call to RegOpen
  name - Name of an application
*/

static Window
RegFindName(NameRegistry *regPtr, char *name)
{
  char *p, *entry;
  Window commWindow;

#ifdef DEBUG
  printf("RegFindName >%s<\n",name);
#endif

  commWindow = None;
  for (p = regPtr->property; (p-regPtr->property) < regPtr->propLength; )
  {
	entry = p;
	while ((*p != 0) && (!isspace((unsigned char)(*p))))
    {
	  p++;
	}
	if ((*p != 0) && (strcmp(name, p+1) == 0))
    {
	  if (sscanf(entry, "%x", (unsigned int *) &commWindow) == 1)
      {
		return(commWindow);
	  }
	}
	while (*p != 0) p++;
	p++;
  }

  return(None);
}

/*
 *----------------------------------------------------------------------
 *
 * RegDeleteName --
 *
 *	This procedure deletes the entry for a given name from
 *	an open registry.
 *
 * regPtr: Pointer to a registry opened with a previous call to RegOpen
 * name: Name of an application
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	If there used to be an entry named "name" in the registry,
 *	then it is deleted and the registry is marked as modified
 *	so it will be written back when closed.
 *
 *----------------------------------------------------------------------
 */
static void
RegDeleteName(NameRegistry *regPtr, char *name)
{
  char *p, *entry, *entryName;
  int count;

#ifdef DEBUG
  printf("RegDeleteName >%s<\n",name);fflush(stdout);
#endif

  for (p = regPtr->property; (p-regPtr->property) < regPtr->propLength; )
  {
	entry = p;
	while ((*p != 0) && (!isspace((unsigned char)(*p))))
    {
	  p++;
	}
	if (*p != 0)
    {
	  p++;
	}
	entryName = p;
	while (*p != 0)
    {
	  p++;
	}
	p++;
	if ((strcmp(name, entryName) == 0))
    {
	  /*
	   * Found the matching entry.  Copy everything after it
	   * down on top of it.
	   */
	  count = regPtr->propLength - (p - regPtr->property);
	  if (count > 0)
      {
		memmove((void *) entry, (void *) p, (size_t) count);
	  }
	  regPtr->propLength -=  p - entry;
	  regPtr->modified = 1;
	  return;
	}
  }
}

/*
 *----------------------------------------------------------------------
 *
 * RegAddName --
 *
 *	Add a new entry to an open registry.
 *
 *   regPtr:	Pointer to a registry opened with a previous call to RegOpen
 *   name: Name of an application.  The caller must ensure that this name isn't already registered
 *   commWindow: X identifier for comm. window of application
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	The open registry is expanded;  it is marked as modified so that
 *	it will be written back when closed.
 *
 *----------------------------------------------------------------------
 */
static void
RegAddName(NameRegistry *regPtr, char *name, Window commWindow)
{
  char id[30];
  char *newProp;
  int idLength, newBytes;

#ifdef DEBUG
  printf("RegAddName >%s<\n",name);
#endif

  sprintf(id, "%x ", (unsigned int) commWindow);
  idLength = strlen(id);
  newBytes = idLength + strlen(name) + 1;
  newProp = (char *) malloc((unsigned) (regPtr->propLength + newBytes));
  strcpy(newProp, id);
  strcpy(newProp+idLength, name);
  if (regPtr->property != NULL)
  {
	memcpy((void *) (newProp + newBytes), (void *) regPtr->property,
		regPtr->propLength);
	if (regPtr->allocedByX)
    {
	    XFree(regPtr->property);
	}
    else
    {
	    free(regPtr->property);
	}
  }
  regPtr->modified = 1;
  regPtr->propLength += newBytes;
  regPtr->property = newProp;
  regPtr->allocedByX = 0;
}

/*
 *----------------------------------------------------------------------
 *
 * RegClose --
 *
 *	This procedure is called to end a series of operations on
 *	a name registry.
 *
 * regPtr: Pointer to a registry opened with a previous call to RegOpen
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	The registry is written back if it has been modified, and the
 *	X server is unlocked if it was locked.  Memory for the
 *	registry is freed, so the caller should never use regPtr
 *	again.
 *
 *----------------------------------------------------------------------
 */

static void
codaRegClose(NameRegistry *regPtr)
{
  Atom registryProperty;

#ifdef DEBUG
  printf("codaRegClose reached\n");fflush(stdout);
#endif

  if (regPtr->modified)
  {
	if (!regPtr->locked)
    {
	  printf("ERRRRRRRRRRRRRRRRRRR: The name registry was modified without being locked!");fflush(stdout);
	}
	registryProperty = XInternAtom(regPtr->dispPtr,"CODARegistry",False);
	XChangeProperty(regPtr->dispPtr,
		            RootWindow(regPtr->dispPtr, 0),
		            registryProperty, XA_STRING, 8,
		            PropModeReplace, (unsigned char *) regPtr->property,
		            (int) regPtr->propLength);
  }

  if (regPtr->locked) XUngrabServer(regPtr->dispPtr);

  XFlush(regPtr->dispPtr);

  if (regPtr->property != NULL)
  {
	if (regPtr->allocedByX)
    {
	  XFree(regPtr->property);
	}
    else
    {
	  free(regPtr->property);
	}
  }

  free((char *) regPtr);
}



/*
    display - Display for which error occurred
    errEventPtr - Information about error
 */
static int
ErrorProc(Display *display, register XErrorEvent *errEventPtr)
{
  printf("ErrorProc reached\n");
  return(0);
}



/*
 *----------------------------------------------------------------------
 *
 * ValidateWindowName --
 *
 *	This procedure checks to see if an entry in the registry
 *	is still valid.
 *
 *  display: Display for which to perform the validation
 *  name: The name of an application
 *  commWindow:	X identifier for the application's comm. window
 *  oldOK: Non-zero means that we should consider an application to be valid even if it
 *         looks like an old-style (pre-4.0) one; 0 means consider these invalid
 *
 * Results:
 *	The return value is 1 if the given commWindow exists and its
 *	name is "name".  Otherwise 0 is returned.
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

static int
ValidateWindowName(Display *display, char *name, Window commWindow, int oldOK)
{
  int result, actualFormat, argc, i;
  unsigned long length, bytesAfter;
  Atom appNameProperty,actualType;
  char *property;

#ifdef DEBUG
  printf("ValidateWindowName >%s<\n",name);fflush(stdout);
#endif

  property = NULL;

  appNameProperty = XInternAtom(display,"CODA_APPLICATION",False);

#ifdef DEBUG
  printf("ValidateWindowName: 1\n");fflush(stdout);
#endif

  /*
   * Ignore X errors when reading the property (e.g., the window
   * might not exist).  If an error occurs, result will be some
   * value other than Success.
   */

  defaultHandler = XSetErrorHandler(ErrorProc);

#ifdef DEBUG
  printf("ValidateWindowName: 2\n");fflush(stdout);
#endif
    
  result = XGetWindowProperty(display, commWindow,
	    appNameProperty, 0, MAX_PROP_WORDS,
	    False, XA_STRING, &actualType, &actualFormat,
	    &length, &bytesAfter, (unsigned char **) &property);

  XSetErrorHandler(defaultHandler);

#ifdef DEBUG
  printf("ValidateWindowName: result=%d actualFormat=%d actualType=%d\n",result,actualFormat,actualType);fflush(stdout);
#endif


  if ((result == Success) && (actualType == None))
  {
    result = 0;
#ifdef DEBUG
  printf("ValidateWindowName: 3\n");fflush(stdout);
#endif
  }
  else if ((result == Success) && (actualFormat == 8) && (actualType == XA_STRING))
  {
	result = 0;
#ifdef DEBUG
  printf("ValidateWindowName: 4\n");fflush(stdout);
#endif
	if (strcmp(property, name) == 0)
    {
	  result = 1;
#ifdef DEBUG
  printf("ValidateWindowName: 5\n");fflush(stdout);
#endif
	}
	else
	{
#ifdef DEBUG
	  printf("ValidateWindowName: property name >%s< not the same as name >%s<\n",property,name);fflush(stdout);
#endif
	}
  }
  else
  {
    result = 0;
#ifdef DEBUG
  printf("ValidateWindowName: 6\n");fflush(stdout);
#endif
  }

  if (property != NULL)
  {
#ifdef DEBUG
  printf("ValidateWindowName: 7\n");fflush(stdout);
#endif
	XFree(property);
  }

#ifdef DEBUG
  printf("ValidateWindowName: 8 result=%d\n",result);fflush(stdout);
#endif
  return(result);
}



/*
 *--------------------------------------------------------------
 *
 * CODASetAppName --
 *
 *	This procedure is called to associate an ASCII name with a Tk
 *	application.  If the application has already been named, the
 *	name replaces the old one.
 *
 * Results:
 *	The return value is the name actually given to the application.
 *	This will normally be the same as name, but if name was already
 *	in use for an application then a name of the form "name #2" will
 *	be chosen,  with a high enough number to make the name unique.
 *
 * Side effects:
 *	Registration info is saved, thereby allowing the "send" command
 *	to be used later to invoke commands in the application.  In
 *	addition, the "send" command is created in the application's
 *	interpreter.  The registration will be removed automatically
 *	if the interpreter is deleted or the "send" command is removed.
 *
 *--------------------------------------------------------------
 */

/*
   window -	 Token for any window in the application
			 to be named:  it is just used to identify
			 the application and the display
   name -  The name that will be used to
		   refer to the interpreter in later
		   "send" commands.  Must be globally unique
 */

char *
CODASetAppName(Display *display, Window window, char *name)
{
  Window w;
  NameRegistry *regPtr;
  char *actualName;
  int offset, i;

#ifdef DEBUG
  printf("CODASetAppName >%s<\n",name);fflush(stdout);
#endif

  /*
   * See if the application is already registered;  if so, remove its
   * current name from the registry.
   */
  /*printf("\n--- CODASetAppName: name >%s<\n",name);*/

  regPtr = codaRegOpen(display, 1);
  /*printf("--- CODASetAppName: regPtr=0x%08x\n",regPtr);*/

  if (RegFindName(regPtr,name) != None)
  {
    printf("CODASetAppName: RegDeleteName >%s< ==================================================\n",name);fflush(stdout);
    RegDeleteName(regPtr, name);
  }

  /*printf("--- CODASetAppName: AddName\n\n");*/
  RegAddName(regPtr, name, window);

  codaRegClose(regPtr);

  UpdateCommWindow(display, window, name);

  return(name);
}



/* returns 'parent' */
int
CODAGetAppWindow(Display *display, char *name)
{
  Window window;
  char *p, *entry, *entryName;
  NameRegistry *regPtr;
  Window commWindow;
  int count;

#ifdef DEBUG
  printf("codaRegistry::CODAGetAppWindow >%s<\n",name);fflush(stdout);
#endif

  /* Read the registry property, then scan through all of its entries.
     Validate each entry to be sure that its application still exists. */

  regPtr = codaRegOpen(display, 1);

#ifdef DEBUG
  printf("codaRegistry::CODAGetAppWindow: regPtr=0x%08x\n",regPtr);fflush(stdout);
  printf("codaRegistry::CODAGetAppWindow: regPtr->property >%s<\n",regPtr->property);fflush(stdout);
  printf("codaRegistry::CODAGetAppWindow: regPtr->propLength=%d\n\n",regPtr->propLength);fflush(stdout);
#endif

  for(p = regPtr->property; (p-regPtr->property) < regPtr->propLength; )
  {
    entry = p;

    if (sscanf(p,"%x",(unsigned int *) &commWindow) != 1)
    {
      commWindow = None;
    }
    else
	{
      /*printf("codaRegistry::CODAGetAppWindow: p >%s<\n",p)*/;
	}

    while((*p != 0) && (!isspace((unsigned char)(*p)))) p++;

    if(*p != 0) p++;

    entryName = p;

    while (*p != 0) p++;
    p++;

#ifdef DEBUG
    printf("codaRegistry::CODAGetAppWindow: entryName >%s<, name >%s<\n",entryName,name);fflush(stdout);
#endif
    if (strcmp(entryName,name) == 0)
    {
      if (ValidateWindowName(display, entryName, commWindow, 1))
      {
	    codaRegClose(regPtr);
	    return(commWindow); 
      }
      else
      {
	    /* This name is bogus (perhaps the application died without
	       cleaning up its entry in the registry?).  Delete the name. */
	
	    count = regPtr->propLength - (p - regPtr->property);
	    if (count > 0)
        {
	      memmove((void *) entry, (void *) p, (size_t) count);
	    }
	    regPtr->propLength -= p - entry;
	    regPtr->modified = 1;
	    p = entry;
      }
    }
  }

  codaRegClose(regPtr);

  return(0);
}

/*
 *--------------------------------------------------------------
 *
 * AppendPropCarefully --
 *
 *	Append a given property to a given window, but set up
 *	an X error handler so that if the append fails this
 *	procedure can return an error code rather than having
 *	Xlib panic.
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	The given property on the given window is appended to.
 *	If this operation fails and if pendingPtr is non-NULL,
 *	then the pending operation is marked as complete with
 *	an error.
 *
 *--------------------------------------------------------------
 */

static void
AppendPropCarefully(display, window, property, value, length, pendingPtr)
    Display *display;		/* Display on which to operate. */
    Window window;		/* Window whose property is to
				 * be modified. */
    Atom property;		/* Name of property. */
    char *value;		/* Characters to append to property. */
    int length;			/* Number of bytes to append. */
    PendingCommand *pendingPtr;	/* Pending command to mark complete
				 * if an error occurs during the
				 * property op.  NULL means just
				 * ignore the error. */
{
#ifdef DEBUG
  printf("AppendPropCarefully reached\n");
#endif

  defaultHandler = XSetErrorHandler(ErrorProc);
  XChangeProperty(display, window, property, XA_STRING, 8,
		  PropModeAppend, (unsigned char *) value, length);
  XSync(display,0);
  XSetErrorHandler(defaultHandler);
}

/*
 *----------------------------------------------------------------------
 *
 * UpdateCommWindow --
 *
 *	This procedure updates the list of application names stored
 *	on our commWindow.  It is typically called when interpreters
 *	are registered and unregistered.
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	The TK_APPLICATION property on the comm window is updated.
 *
 *----------------------------------------------------------------------
 */

static void
UpdateCommWindow(Display *display, Window window, char *name)
{
  Atom appNameProperty;

#ifdef DEBUG
  printf("UpdateCommWindow >%s<\n",name);fflush(stdout);
#endif

  defaultHandler = XSetErrorHandler(ErrorProc);
  appNameProperty = XInternAtom(display,"CODA_APPLICATION",False);
  XChangeProperty(display, window,
		  appNameProperty, XA_STRING, 8, PropModeReplace,
		  (unsigned char *) name,
		  strlen(name));
  XSetErrorHandler(defaultHandler);
}




/********************************************************************/
/********************************************************************/



/*
 *--------------------------------------------------------------
 *
 * Tk_SendCmd --
 *
 *	This procedure is invoked to process the "send" Tcl command.
 *	See the user documentation for details on what it does.
 *
 * Results:
 *	A standard Tcl result.
 *
 * Side effects:
 *	See the user documentation.
 *
 *--------------------------------------------------------------
 */

int
coda_Send(Display *display, char *destName, char *cmd)
{
  Window commWindow;
  int result, c, async, i, firstArg;
  size_t length;
  NameRegistry *regPtr;

#ifdef DEBUG
  printf("coda_Send: cmd >%s<\n",cmd);fflush(stdout);
#endif

  Atom commProperty = XInternAtom(display,"COMM",False);
  defaultHandler = XSetErrorHandler(ErrorProc);

  /*
   * Bind the interpreter name to a communication window.
   */
  regPtr = codaRegOpen(display, 1);
  commWindow = RegFindName(regPtr, destName);
  if (ValidateWindowName(display, destName, commWindow, 1) == 0)
  {
    /*
     * This name is bogus (perhaps the application died without
     * cleaning up its entry in the registry?).  Delete the name.
     */

#ifdef DEBUG
	printf("coda_Send: deleting name >%s< !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n",destName);fflush(stdout);
	printf("coda_Send: deleting name >%s< !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n",destName);fflush(stdout);
	printf("coda_Send: deleting name >%s< !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n",destName);fflush(stdout);
#endif

    RegDeleteName(regPtr,destName);
    commWindow == None;
  }

  codaRegClose(regPtr);
  if (commWindow == None)
  {
    return(1);
  } 

  (void) AppendPropCarefully(display, commWindow,
			       commProperty, cmd,
			       strlen(cmd) + 1,
			       (PendingCommand *) NULL);

  return(0);
}



static void
resizeHandler(Widget w, Window target, XEvent *eventPtr)
{
  XWindowChanges wc;

/*#ifdef DEBUG*/
  printf("codaRegistry::resizeHandler reached\n");fflush(stdout);
/*#endif*/

  wc.x = 0;
  wc.y = 0;
  wc.width  = eventPtr->xconfigure.width;
  wc.height = eventPtr->xconfigure.height;
  wc.border_width = 0;
  wc.sibling = None;
  wc.stack_mode = Above;
	  /*
int XConfigureWindow(Display *display, Window w, unsigned value_mask, XWindowChanges *changes); 
	  */
  /*sergey: called when switch tabs in 'rocs', currently scruds up everything, but can be useful if set correctly*/
  /*XConfigureWindow(XtDisplay(w), target, CWWidth | CWHeight, &wc);*/
}

static void 
exposeHandler(Widget w, Window target, XEvent *eventPtr)
{
  XWindowChanges wc;

#ifdef DEBUG
  printf("codaRegistry::exposeHandler reached\n");fflush(stdout);
#endif

  wc.x = 0;
  wc.y = 0;
  wc.width  = eventPtr->xexpose.width;
  wc.height = eventPtr->xexpose.height;
  wc.border_width = 0;
  wc.sibling = None;
  wc.stack_mode = Above;
  XConfigureWindow(XtDisplay(w),target, CWWidth | CWHeight, &wc);
}

typedef void (*MSG_FUNCPTR) (char *);
static void (*messageCallback)(char *message) = NULL;

void
codaRegisterMsgCallback(void *callback)
{
  messageCallback = (MSG_FUNCPTR) callback;
}




























static /*void*/XtEventHandler
motifHandler(Widget w, XtPointer p, XEvent *eventPtr)
/*
XtEventHandler
motifHandler(Widget w, XtPointer p, XEvent *eventPtr)
*/
{
  Atom commProperty;
  char *propInfo;
  int result, actualFormat;
  unsigned long numItems, bytesAfter;
  long long_offset, long_length;

  /*int abc1[100];*/ /*sergey: segfault without it ... */
  Atom actualType;
  /*int abc2[100];*/ /*sergey: segfault without it ... */

  Widget w1;
  Widget w2;
  Display *dis;
  Window win;
  /*int abc[100];* /*sergey: segfault without it ... */

  int x, y, wid, hit, bw, d;
  Window root;

	  /*sergey
	  Widget target;
	  */
      Window target;

	  /*sergey
      Widget parent;
	  */
      Drawable parent;

	  int counter1;
	  XWindowChanges wc;



	  HANDLER_LOCK;


  /*
  abc[0] = -1;
  */

#ifdef DEBUG
  printf("codaRegistry::motifHandler reached\n");fflush(stdout);
  printf("codaRegistry::motifHandler input params: 0x%08x 0x%08x 0x%08x\n", w, p, eventPtr);fflush(stdout);
  printf("codaRegistry::motifHandler Atom sizes: %d %d\n",sizeof(Atom),sizeof(actualType));fflush(stdout);
#endif


  dis = XtDisplay(w);
  win = XtWindow(w);
  /*printf("codaRegistry::motifHandler: dis=0x%08x, win=0x%08x\n",dis,win);*/



/*
printf("abc1 %d\n",abc[0]);fflush(stdout);
*/
/*
Atom XInternAtom(display, atom_name, only_if_exists)
      Display *display;
      char *atom_name;
      Bool only_if_exists;
*/
  commProperty = XInternAtom(XtDisplay(w),"COMM",False);
#ifdef DEBUG
  printf("codaRegistry::motifHandler: commProperty = 0x%08x\n",commProperty);
  printf("codaRegistry::motifHandler: PropertyNewValue = 0x%08x\n",PropertyNewValue);
#endif

  if (eventPtr->xproperty.atom != commProperty)
  {
#ifdef DEBUG
    printf("codaRegistry::motifHandler: early return 1 (eventPtr->xproperty.atom=0x%08x)\n",eventPtr->xproperty.atom);
#endif
    /*XFree(commProperty);*/ /*sergey ??? segfault*/
    HANDLER_UNLOCK;
    return;
  }

  if (eventPtr->xproperty.state != PropertyNewValue)
  {
#ifdef DEBUG
    printf("codaRegistry::motifHandler: early return 2 (eventPtr->xproperty.state=0x%08x)\n",eventPtr->xproperty.state);
#endif
    /*XFree(commProperty);*/ /*sergey ??? segfault*/
    HANDLER_UNLOCK;
    return;
  }

/*
int XGetWindowProperty(display, w, property, long_offset, long_length, delete, req_type, 
                        actual_type_return, actual_format_return, nitems_return, bytes_after_return, 
                        prop_return)
      Display *display;
      Window w;
      Atom property;
      long long_offset, long_length;
      Bool delete;
      Atom req_type; 
      Atom *actual_type_return;
      int *actual_format_return;
      unsigned long *nitems_return;
      unsigned long *bytes_after_return;
      unsigned char **prop_return;
*/

  /* Read the comm property and delete it */
  propInfo = NULL;
  long_offset = 0;
  long_length = MAX_PROP_WORDS;
  result = XGetWindowProperty(dis,
				              win,
                              commProperty, long_offset, long_length, True,
							  (Atom)XA_STRING, &actualType, &actualFormat,
				  &numItems, &bytesAfter, (unsigned char **) &propInfo);

/*
printf("abc2 %d\n",abc[0]);fflush(stdout);
*/

#ifdef DEBUG
  printf("codaRegistry::motifHandler: propInfo = 0x%08x, result=%d\n",propInfo,result);fflush(stdout);
  printf("codaRegistry::motifHandler: propInfo >%s<\n\n",propInfo);fflush(stdout);
#endif

  if (propInfo)
  {
    if (propInfo[0] == 'r')
    {

	  sscanf(&propInfo[2],"%x %x",&target,&parent);

	  /*
	  printf("sizes: target=%d parent=%d\n",sizeof(target),sizeof(parent));
	  printf("target=0x%08x parent=0x%08x\n",target,parent);
	  */

	  /*
Status XGetGeometry(display, d, root_return, x_return, y_return, width_return, 
                      height_return, border_width_return, depth_return)
        Display *display;
        Drawable d;
        Window *root_return;
        int *x_return, *y_return;
        unsigned int *width_return, *height_return;
        unsigned int *border_width_return;
        unsigned int *depth_return;
	  */

	  XGetGeometry(XtDisplay(w),parent,&root,&x,&y,&wid,&hit,&bw,&d);
	  wc.x = 0;
      wc.y = 0;
      wc.width  = wid;
      wc.height = hit;
      wc.border_width = 0;
      wc.sibling = None;
      wc.stack_mode = Above;
	  /*
int XConfigureWindow(Display *display, Window w, unsigned value_mask, XWindowChanges *changes); 
	  */
      XConfigureWindow(XtDisplay(w),target, CWWidth | CWHeight, &wc);

	  XWithdrawWindow(XtDisplay(w), target,0);
	  for (counter1 = 0; counter1 < 25; counter1++)
      {
	    XReparentWindow(XtDisplay(w),target,parent,0,0);
	    XSync(XtDisplay(w), False);
	  }
	   
	  XMapWindow(XtDisplay(w), target);  
	  /*
void XtAddEventHandler(Widget w, EventMask event_mask, Boolean nonmaskable, XtEventHandler proc, XtPointer client_data);
	  */

/*
printf("abc3 %d\n",abc[0]);fflush(stdout);
*/
/*
      Display *XtDisplay(Widget w); 
      Widget XtWindowToWidget(Display *display, Window window); 
	  Widget XtParent(Widget w);
*/

#ifdef DEBUG
	  printf("codaRegistry::motifHandler: BEFOR ?\n");fflush(stdout);
#endif

      dis = XtDisplay(w);

#ifdef DEBUG
	  printf("codaRegistry::motifHandler: BEFOR ?? (0x%08x) (0x%08x)\n",dis,parent);fflush(stdout);
#endif

      w2 = XtWindowToWidget(dis, parent);

#ifdef DEBUG
	  printf("codaRegistry::motifHandler: BEFOR ??? (0x%08x)\n",w2);fflush(stdout);
#endif
      if(w2==NULL)
	  {
#ifdef DEBUG
        printf("codaRegistry::motifHandler: FATAL ERROR: w2=0x%08x\n",w2);fflush(stdout);
#endif
        return;
	  }

	  w1 = XtParent(w2);

/*
printf("abc4 %d\n",abc[0]);fflush(stdout);
*/
#ifdef DEBUG
	  printf("codaRegistry::motifHandler: BEFOR !\n");fflush(stdout);	  
#endif

	  XtAddEventHandler( (Widget)w1, (EventMask)StructureNotifyMask, (Boolean)False, (XtEventHandler)resizeHandler, (XtPointer)target);

#ifdef DEBUG
	  printf("codaRegistry::motifHandler: AFTER\n");fflush(stdout);
#endif

	  /*XtAddEventHandler(XtWindowToWidget(XtDisplay(w),parent),ExposureMask, False, exposeHandler, target);*/
    }
    else if (messageCallback)
	{
#ifdef DEBUG
      printf("??? propInfo[0] = %c\n",propInfo[0]);
#endif
	  (*messageCallback)(propInfo);
	}

    XFree(propInfo); /*release memory*/
  }
  else
  {
    /* if we are here, window is not embedded, it opens separately */
#ifdef DEBUG
    printf("??? There is no propInfo\n");
#endif
  }

  HANDLER_UNLOCK;
}


int
codaSendInit(Widget w, char *name)
{
  XSetWindowAttributes atts;

#ifdef DEBUG
  printf("codaSendInit: name >%s<\n",name);
#endif

  XtAddEventHandler(w, PropertyChangeMask, False, (XtEventHandler)motifHandler, (XtPointer)NULL);

  /* if commented out, handler returns 'early return 1' */
  CODASetAppName(XtDisplay(w), XtWindow(w), name);

  return(0);
}

































/************************/
/************************/
/************************/
/* currently not in use */
/************************/
/************************/
/************************/

/*
 *----------------------------------------------------------------------
 *
 * TkGetInterpNames --
 *
 *	This procedure is invoked to fetch a list of all the
 *	interpreter names currently registered for the display
 *	of a particular window.
 *
 * Results:
 *	A standard Tcl return value.  Interp->result will be set
 *	to hold a list of all the interpreter names defined for
 *	tkwin's display.  If an error occurs, then 1
 *	is returned and interp->result will hold an error message.
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

char *
CODAGetAppNames_hide(Display *display)
{
  Window window;
  char *p, *entry, *entryName;
  NameRegistry *regPtr;
  Window commWindow;
  int count;

  char *names = NULL;
    /*
     * Read the registry property, then scan through all of its entries.
     * Validate each entry to be sure that its application still exists.

     */
    regPtr = codaRegOpen(display, 1);

    for (p = regPtr->property; (p-regPtr->property) < regPtr->propLength; ) {
      entry = p;
      if (sscanf(p,  "%x",(unsigned int *) &commWindow) != 1) {
	commWindow =  None;
      }
      while ((*p != 0) && (!isspace((unsigned char)(*p)))) {
	p++;
      }
      if (*p != 0) {
	p++;
      }
      entryName = p;
      while (*p != 0) {
	p++;
      }
      p++;
      if (ValidateWindowName(display, entryName, commWindow, 1)) {
	/*
	 * The application still exists; add its name to the result.
	 */
	if (names == NULL) {
	  names = (char *) malloc(strlen(entryName)+1);
	  strcpy(names,entryName);
	} else {
	  names = (char *) realloc(names,strlen(names)+strlen(entryName)+2);
	  strcat(names," ");
	  strcat(names,entryName);
	}
      } else {
	/*
	 * This name is bogus (perhaps the application died without
	 * cleaning up its entry in the registry?).  Delete the name.
	 */
	
	count = regPtr->propLength - (p - regPtr->property);
	if (count > 0)  {
	  memmove((void *) entry, (void *) p, (size_t) count);
	}
	regPtr->propLength -= p - entry;
	regPtr->modified = 1;
	p = entry;
      }
    }
    codaRegClose(regPtr);
    return names;
}
/*
 *----------------------------------------------------------------------
 *
 * ServerSecure --
 *
 *	Check whether a server is secure enough for us to trust
 *	Tcl scripts arriving via that server.
 *
 * Results:
 *	The return value is 1 if the server is secure, which means
 *	that host-style authentication is turned on but there are
 *	no hosts in the enabled list.  This means that some other
 *	form of authorization (presumably more secure, such as xauth)
 *	is in use.
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

static int
ServerSecure_hide(display)
    Display *display;		/* Display to check. */
{
    XHostAddress *addrPtr;
    int numHosts, secure;
    Bool enabled;

    secure = 0;
    addrPtr = XListHosts(display, &numHosts, &enabled);
    if (enabled && (numHosts == 0)) {
	secure = 1;
    }
    if (addrPtr != NULL) {
	XFree((char *) addrPtr);
    }
    return secure;
}
