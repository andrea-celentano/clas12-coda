#ifndef __CODA_REGISTRY
#define __CODA_REGISTRY


typedef struct NameRegistry {
    Display *dispPtr;		/* Display from which the registry was
				 * read. */
    int locked;			/* Non-zero means that the display was
				 * locked when the property was read in. */
    int modified;		/* Non-zero means that the property has
				 * been modified, so it needs to be written
				 * out when the NameRegistry is closed. */
    unsigned long propLength;	/* Length of the property, in bytes. */
    char *property;		/* The contents of the property, or NULL
				 * if none.  See format description above;
				 * this is *not* terminated by the first
				 * null character.  Dynamically allocated. */
    int allocedByX;		/* Non-zero means must free property with
				 * XFree;  zero means use free. */
} NameRegistry;

typedef struct PendingCommand {
    int serial;			/* Serial number expected in result */
    Display *dispPtr;	/* Display being used for communication */
    char *target;		/* Name of interpreter command is being sent to */
    Window commWindow;	/* Target's communication window */
    int code;			/* Tcl return code for command
				 * will be stored here. */
    char *result;		/* String result for command (malloc'ed),
				 * or NULL. */
    char *errorInfo;		/* Information for "errorInfo" variable,
				 * or NULL (malloc'ed). */
    char *errorCode;		/* Information for "errorCode" variable,
				 * or NULL (malloc'ed). */
    int gotResponse;		/* 1 means a response has been received,
				 * 0 means the command is still outstanding. */
    struct PendingCommand *nextPtr;
				/* Next in list of all outstanding
				 * commands.  NULL means end of
				 * list. */
} PendingCommand;


/* functions */

#ifdef __cplusplus
extern "C" {
#endif


char   *CODASetAppName (Display *display, Window window, char *name);
int     CODAGetAppWindow (Display *display, char *name);
int     coda_Send (Display *display, char *destName, char *cmd);
void    codaRegisterMsgCallback (void *callback);
int     codaSendInit (Widget w, char *name);


char   *CODAGetAppNames_hide (Display *display);

#ifdef __cplusplus
}
#endif

#endif

